const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

// Database Connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "abacademy"
});

db.connect((err) => {
    if (err) {
        console.log("Database Connection Failed");
        console.log(err);
        return;
    }

    console.log("Database Connected Successfully");
});

// Home Route
app.get("/", (req, res) => {
    res.send("Welcome to ABACADEMY.COM Server");
});

// Student Login
app.post("/student/login", (req, res) => {

    const { username, password } = req.body;

    const sql =
        "SELECT * FROM students WHERE username=? AND password=?";

    db.query(sql, [username, password], (err, result) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Server Error"
            });
        }

        if (result.length > 0) {

            return res.json({
                success: true,
                message: "Student Login Successful",
                student: result[0]
            });

        }

        return res.json({
            success: false,
            message: "Invalid Username or Password"
        });

    });

});

// Admin Login
app.post("/admin/login", (req, res) => {

    const { username, password } = req.body;

    const sql =
        "SELECT * FROM admins WHERE username=? AND password=?";

    db.query(sql, [username, password], (err, result) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Server Error"
            });
        }

        if (result.length > 0) {

            return res.json({
                success: true,
                message: "Admin Login Successful",
                admin: result[0]
            });

        }

        return res.json({
            success: false,
            message: "Invalid Admin Username or Password"
        });

    });

});

// Server Port
const PORT = 3000;

app.listen(PORT, () => {
    console.log(`ABACADEMY Server Running On Port ${PORT}`);
});// =====================================
// STUDENT MANAGEMENT
// =====================================

// Get All Students
app.get("/students", (req, res) => {

    const sql = "SELECT * FROM students ORDER BY id DESC";

    db.query(sql, (err, result) => {

        if (err) {
            return res.status(500).json({
                success: false,
                message: "Database Error"
            });
        }

        res.json(result);

    });

});

// Add Student
app.post("/students/add", (req, res) => {

    const {
        username,
        password,
        fullname,
        email,
        phone
    } = req.body;

    const sql =
    "INSERT INTO students(username,password,fullname,email,phone) VALUES(?,?,?,?,?)";

    db.query(
        sql,
        [username,password,fullname,email,phone],
        (err,result)=>{

            if(err){
                return res.status(500).json({
                    success:false,
                    message:"Unable to Add Student"
                });
            }

            res.json({
                success:true,
                message:"Student Added Successfully"
            });

        }

    );

});

// Delete Student
app.delete("/students/:id", (req,res)=>{

    const id=req.params.id;

    db.query(
        "DELETE FROM students WHERE id=?",
        [id],
        (err,result)=>{

            if(err){
                return res.status(500).json({
                    success:false
                });
            }

            res.json({
                success:true,
                message:"Student Deleted Successfully"
            });

        }
    );

});// =====================================
// STUDENT UPDATE & SECURITY
// =====================================

// Search Student
app.get("/students/search/:username", (req, res) => {

    const username = "%" + req.params.username + "%";

    db.query(
        "SELECT * FROM students WHERE username LIKE ?",
        [username],
        (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            res.json(result);

        }
    );

});

// Update Student
app.put("/students/update/:id", (req, res) => {

    const id = req.params.id;

    const {
        fullname,
        email,
        phone
    } = req.body;

    db.query(

        "UPDATE students SET fullname=?,email=?,phone=? WHERE id=?",

        [fullname, email, phone, id],

        (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            res.json({
                success: true,
                message: "Student Updated Successfully"
            });

        }

    );

});

// Block Student
app.put("/students/block/:id", (req, res) => {

    const id = req.params.id;

    db.query(

        "UPDATE students SET status='blocked' WHERE id=?",

        [id],

        (err, result) => {

            if (err) {

                return res.status(500).json({
                    success: false
                });

            }

            res.json({
                success: true,
                message: "Student Blocked"
            });

        }

    );

});

// Unblock Student
app.put("/students/unblock/:id", (req, res) => {

    const id = req.params.id;

    db.query(

        "UPDATE students SET status='active' WHERE id=?",

        [id],

        (err, result) => {

            if (err) {

                return res.status(500).json({
                    success: false
                });

            }

            res.json({
                success: true,
                message: "Student Activated"
            });

        }

    );

});

// Reset Password
app.put("/students/reset-password/:id", (req, res) => {

    const id = req.params.id;

    const { password } = req.body;

    db.query(

        "UPDATE students SET password=? WHERE id=?",

        [password, id],

        (err, result) => {

            if (err) {

                return res.status(500).json({
                    success: false
                });

            }

            res.json({
                success: true,
                message: "Password Reset Successfully"
            });

        }

    );

});// =====================================
// MCQ MANAGEMENT
// =====================================

// Get All MCQs
app.get("/mcqs", (req, res) => {

    db.query("SELECT * FROM mcqs ORDER BY id DESC", (err, result) => {

        if (err) {
            return res.status(500).json({
                success: false
            });
        }

        res.json(result);

    });

});

// Add MCQ
app.post("/mcqs/add", (req, res) => {

    const {

        subject,
        chapter,
        topic,
        question,
        optionA,
        optionB,
        optionC,
        optionD,
        answer

    } = req.body;

    const sql =

    "INSERT INTO mcqs(subject,chapter,topic,question,optionA,optionB,optionC,optionD,answer) VALUES(?,?,?,?,?,?,?,?,?)";

    db.query(

        sql,

        [
            subject,
            chapter,
            topic,
            question,
            optionA,
            optionB,
            optionC,
            optionD,
            answer
        ],

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success: false,
                    message: "Unable to Add MCQ"

                });

            }

            res.json({

                success: true,
                message: "MCQ Added Successfully"

            });

        }

    );

});

// Delete MCQ
app.delete("/mcqs/:id", (req, res) => {

    db.query(

        "DELETE FROM mcqs WHERE id=?",

        [req.params.id],

        (err, result) => {

            if (err) {

                return res.status(500).json({
                    success: false
                });

            }

            res.json({

                success: true,
                message: "MCQ Deleted Successfully"

            });

        }

    );

});

// Search MCQs
app.get("/mcqs/search/:subject", (req, res) => {

    db.query(

        "SELECT * FROM mcqs WHERE subject=?",

        [req.params.subject],

        (err, result) => {

            if (err) {

                return res.status(500).json({
                    success: false
                });

            }

            res.json(result);

        }

    );

});// =====================================
// PRACTICE MCQ API
// =====================================

// Get Subjects
app.get("/subjects", (req, res) => {

    db.query(
        "SELECT DISTINCT subject FROM mcqs",
        (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            res.json(result);

        }
    );

});

// Get Chapters
app.get("/chapters/:subject", (req, res) => {

    db.query(

        "SELECT DISTINCT chapter FROM mcqs WHERE subject=?",

        [req.params.subject],

        (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            res.json(result);

        }

    );

});

// Get Topics
app.get("/topics/:subject/:chapter", (req, res) => {

    db.query(

        "SELECT DISTINCT topic FROM mcqs WHERE subject=? AND chapter=?",

        [

            req.params.subject,

            req.params.chapter

        ],

        (err, result) => {

            if (err) {
                return res.status(500).json({
                    success: false
                });
            }

            res.json(result);

        }

    );

});

// Start Practice
app.post("/practice/start", (req, res) => {

    const {

        subject,
        chapter,
        topic,
        total

    } = req.body;

    db.query(

        "SELECT * FROM mcqs WHERE subject=? AND chapter=? AND topic=? ORDER BY RAND() LIMIT ?",

        [

            subject,

            chapter,

            topic,

            total

        ],

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success: false

                });

            }

            res.json({

                success: true,

                mcqs: result

            });

        }

    );

});// =====================================
// RESULT MANAGEMENT API
// =====================================

// Submit Practice Result
app.post("/practice/submit", (req, res) => {

    const {

        student_id,
        subject,
        chapter,
        topic,
        total_questions,
        correct_answers,
        wrong_answers,
        percentage

    } = req.body;

    const sql = `
    INSERT INTO results
    (
        student_id,
        subject,
        chapter,
        topic,
        total_questions,
        correct_answers,
        wrong_answers,
        percentage
    )
    VALUES (?,?,?,?,?,?,?,?)
    `;

    db.query(

        sql,

        [

            student_id,
            subject,
            chapter,
            topic,
            total_questions,
            correct_answers,
            wrong_answers,
            percentage

        ],

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success:false,
                    message:"Unable to Save Result"

                });

            }

            res.json({

                success:true,
                message:"Result Saved Successfully"

            });

        }

    );

});

// Student Result History
app.get("/results/:studentId",(req,res)=>{

    db.query(

        "SELECT * FROM results WHERE student_id=? ORDER BY id DESC",

        [req.params.studentId],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json(result);

        }

    );

});

// Student Overall Statistics
app.get("/statistics/:studentId",(req,res)=>{

    db.query(

        `SELECT

        COUNT(id) AS tests,

        SUM(correct_answers) AS correct,

        SUM(wrong_answers) AS wrong,

        AVG(percentage) AS average

        FROM results

        WHERE student_id=?`,

        [req.params.studentId],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json(result[0]);

        }

    );

});// =====================================
// ONLINE TEST MANAGEMENT
// =====================================

// Get All Active Tests
app.get("/tests", (req, res) => {

    db.query(

        "SELECT * FROM online_tests WHERE status='active' ORDER BY id DESC",

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success: false

                });

            }

            res.json(result);

        }

    );

});

// Create New Online Test
app.post("/tests/create", (req, res) => {

    const {

        title,
        description,
        subject,
        chapter,
        topic,
        total_questions,
        duration,
        start_time,
        end_time

    } = req.body;

    const sql =

    `INSERT INTO online_tests

    (title,description,subject,chapter,topic,total_questions,duration,start_time,end_time,status)

    VALUES(?,?,?,?,?,?,?,?,?,'active')`;

    db.query(

        sql,

        [

            title,
            description,
            subject,
            chapter,
            topic,
            total_questions,
            duration,
            start_time,
            end_time

        ],

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success: false,
                    message: "Unable To Create Test"

                });

            }

            res.json({

                success: true,
                message: "Online Test Created Successfully"

            });

        }

    );

});

// Start Online Test
app.get("/tests/start/:id", (req, res) => {

    db.query(

        "SELECT * FROM online_tests WHERE id=?",

        [req.params.id],

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success: false

                });

            }

            res.json(result[0]);

        }

    );

});

// Delete Test
app.delete("/tests/:id", (req, res) => {

    db.query(

        "DELETE FROM online_tests WHERE id=?",

        [req.params.id],

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success: false

                });

            }

            res.json({

                success: true,
                message: "Test Deleted Successfully"

            });

        }

    );

});// =====================================
// ONLINE TEST RESULTS & RANKINGS
// =====================================

// Submit Online Test
app.post("/tests/submit", (req, res) => {

    const {

        student_id,
        test_id,
        score,
        total_questions,
        percentage,
        time_taken

    } = req.body;

    const sql =

    `INSERT INTO test_results
    (student_id,test_id,score,total_questions,percentage,time_taken)
    VALUES(?,?,?,?,?,?)`;

    db.query(

        sql,

        [

            student_id,
            test_id,
            score,
            total_questions,
            percentage,
            time_taken

        ],

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success:false,
                    message:"Unable To Save Result"

                });

            }

            res.json({

                success:true,
                message:"Result Submitted Successfully"

            });

        }

    );

});

// Student Test History
app.get("/tests/history/:studentId",(req,res)=>{

    db.query(

        "SELECT * FROM test_results WHERE student_id=? ORDER BY id DESC",

        [req.params.studentId],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json(result);

        }

    );

});

// Leaderboard
app.get("/tests/leaderboard/:testId",(req,res)=>{

    db.query(

        `SELECT
        student_id,
        score,
        percentage,
        time_taken
        FROM test_results
        WHERE test_id=?
        ORDER BY score DESC,
        time_taken ASC`,

        [req.params.testId],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json(result);

        }

    );

});

// Admin View All Results
app.get("/admin/test-results",(req,res)=>{

    db.query(

        "SELECT * FROM test_results ORDER BY id DESC",

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json(result);

        }

    );

});// =====================================
// NOTES MANAGEMENT
// =====================================

// Get All Notes
app.get("/notes", (req, res) => {

    db.query(

        "SELECT * FROM notes ORDER BY id DESC",

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success: false

                });

            }

            res.json(result);

        }

    );

});

// Add Notes
app.post("/notes/add", (req, res) => {

    const {

        subject,
        chapter,
        title,
        description,
        price,
        pdf_link

    } = req.body;

    const sql =

    `INSERT INTO notes
    (subject,chapter,title,description,price,pdf_link)
    VALUES(?,?,?,?,?,?)`;

    db.query(

        sql,

        [

            subject,
            chapter,
            title,
            description,
            price,
            pdf_link

        ],

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success:false,
                    message:"Unable To Add Notes"

                });

            }

            res.json({

                success:true,
                message:"Notes Added Successfully"

            });

        }

    );

});

// Delete Notes
app.delete("/notes/:id",(req,res)=>{

    db.query(

        "DELETE FROM notes WHERE id=?",

        [req.params.id],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json({

                success:true,
                message:"Notes Deleted Successfully"

            });

        }

    );

});

// Purchase History
app.get("/notes/purchases/:studentId",(req,res)=>{

    db.query(

        "SELECT * FROM notes_purchases WHERE student_id=? ORDER BY id DESC",

        [req.params.studentId],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json(result);

        }

    );

});

// Buy Notes
app.post("/notes/buy",(req,res)=>{

    const {

        student_id,
        notes_id,
        payment_method

    } = req.body;

    db.query(

        `INSERT INTO notes_purchases
        (student_id,notes_id,payment_method)
        VALUES(?,?,?)`,

        [

            student_id,
            notes_id,
            payment_method

        ],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false,
                    message:"Purchase Failed"

                });

            }

            res.json({

                success:true,
                message:"Notes Purchased Successfully"

            });

        }

    );

});// =====================================
// ADMIN DASHBOARD ANALYTICS
// =====================================

// Dashboard Statistics
app.get("/dashboard/statistics", (req, res) => {

    const sql = `
    SELECT
    (SELECT COUNT(*) FROM students) AS total_students,
    (SELECT COUNT(*) FROM mcqs) AS total_mcqs,
    (SELECT COUNT(*) FROM online_tests) AS total_tests,
    (SELECT COUNT(*) FROM notes) AS total_notes
    `;

    db.query(sql, (err, result) => {

        if (err) {

            return res.status(500).json({

                success: false,
                message: "Database Error"

            });

        }

        res.json(result[0]);

    });

});

// Top Students
app.get("/dashboard/top-students", (req, res) => {

    const sql = `
    SELECT
    student_id,
    AVG(percentage) AS average_percentage
    FROM results
    GROUP BY student_id
    ORDER BY average_percentage DESC
    LIMIT 10
    `;

    db.query(sql, (err, result) => {

        if (err) {

            return res.status(500).json({

                success: false

            });

        }

        res.json(result);

    });

});

// Recent Student Registrations
app.get("/dashboard/recent-students", (req, res) => {

    db.query(

        "SELECT * FROM students ORDER BY created_at DESC LIMIT 10",

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success: false

                });

            }

            res.json(result);

        }

    );

});

// Recent Test Results
app.get("/dashboard/recent-results", (req, res) => {

    db.query(

        "SELECT * FROM test_results ORDER BY id DESC LIMIT 10",

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success: false

                });

            }

            res.json(result);

        }

    );

});

// Website Status
app.get("/dashboard/status", (req, res) => {

    res.json({

        success: true,
        website: "Online",
        database: "Connected",
        server: "Running",
        version: "ABACADEMY v1.0"

    });

});// =====================================
// NOTIFICATION & ANNOUNCEMENT SYSTEM
// =====================================

// Get All Notifications
app.get("/notifications", (req, res) => {

    db.query(

        "SELECT * FROM notifications ORDER BY id DESC",

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success: false

                });

            }

            res.json(result);

        }

    );

});

// Send Notification
app.post("/notifications/send", (req, res) => {

    const {

        title,
        message,
        type

    } = req.body;

    const sql =

    `INSERT INTO notifications
    (title,message,type)
    VALUES(?,?,?)`;

    db.query(

        sql,

        [

            title,
            message,
            type

        ],

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success:false,
                    message:"Unable To Send Notification"

                });

            }

            res.json({

                success:true,
                message:"Notification Sent Successfully"

            });

        }

    );

});

// Delete Notification
app.delete("/notifications/:id", (req, res) => {

    db.query(

        "DELETE FROM notifications WHERE id=?",

        [req.params.id],

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success:false

                });

            }

            res.json({

                success:true,
                message:"Notification Deleted"

            });

        }

    );

});

// Latest Announcement
app.get("/announcement/latest", (req, res) => {

    db.query(

        "SELECT * FROM notifications WHERE type='announcement' ORDER BY id DESC LIMIT 1",

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success:false

                });

            }

            res.json(result[0]);

        }

    );

});

// Broadcast Announcement
app.post("/announcement/broadcast", (req, res) => {

    const {

        title,
        message

    } = req.body;

    db.query(

        `INSERT INTO notifications
        (title,message,type)
        VALUES(?,?,'announcement')`,

        [

            title,
            message

        ],

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success:false

                });

            }

            res.json({

                success:true,
                message:"Announcement Broadcast Successfully"

            });

        }

    );

});// =====================================
// SECURITY & SESSION MANAGEMENT
// =====================================

const crypto = require("crypto");

// Generate Device ID
function generateDeviceId() {

    return crypto.randomBytes(16).toString("hex");

}

// Student Secure Login
app.post("/student/secure-login", (req, res) => {

    const {

        username,
        password,
        device_id

    } = req.body;

    db.query(

        "SELECT * FROM students WHERE username=? AND password=?",

        [

            username,
            password

        ],

        (err, result) => {

            if (err) {

                return res.status(500).json({

                    success:false

                });

            }

            if(result.length===0){

                return res.json({

                    success:false,
                    message:"Invalid Username or Password"

                });

            }

            const student=result[0];

            if(

                student.device_id &&
                student.device_id!==device_id

            ){

                return res.json({

                    success:false,
                    message:"This account is already logged in on another device."

                });

            }

            db.query(

                "UPDATE students SET device_id=? WHERE id=?",

                [

                    device_id || generateDeviceId(),

                    student.id

                ],

                ()=>{

                    res.json({

                        success:true,
                        student

                    });

                }

            );

        }

    );

});

// Logout Student
app.post("/student/logout",(req,res)=>{

    const {

        student_id

    }=req.body;

    db.query(

        "UPDATE students SET device_id=NULL WHERE id=?",

        [

            student_id

        ],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json({

                success:true,
                message:"Logged Out Successfully"

            });

        }

    );

});

// Activity Logs
app.post("/activity-log",(req,res)=>{

    const {

        student_id,
        activity

    }=req.body;

    db.query(

        `INSERT INTO activity_logs
        (student_id,activity)
        VALUES(?,?)`,

        [

            student_id,
            activity

        ],

        ()=>{

            res.json({

                success:true

            });

        }

    );

});

// View Activity Logs
app.get("/activity-log/:studentId",(req,res)=>{

    db.query(

        "SELECT * FROM activity_logs WHERE student_id=? ORDER BY id DESC",

        [

            req.params.studentId

        ],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json(result);

        }

    );

});// =====================================
// FILE UPLOAD MANAGEMENT
// =====================================

const multer = require("multer");
const path = require("path");

// Storage Configuration
const storage = multer.diskStorage({

    destination: function(req, file, cb){

        cb(null,"uploads/");

    },

    filename: function(req,file,cb){

        const uniqueName =
        Date.now() + "-" + file.originalname;

        cb(null,uniqueName);

    }

});

const upload = multer({

    storage: storage,

    limits: {

        fileSize: 20 * 1024 * 1024

    }

});

// Upload PDF Notes
app.post(

"/upload/notes",

upload.single("pdf"),

(req,res)=>{

    res.json({

        success:true,

        filename:req.file.filename,

        path:req.file.path

    });

});

// Upload Student Image
app.post(

"/upload/profile",

upload.single("image"),

(req,res)=>{

    res.json({

        success:true,

        filename:req.file.filename,

        path:req.file.path

    });

});

// Upload MCQ Excel File
app.post(

"/upload/mcqs",

upload.single("excel"),

(req,res)=>{

    res.json({

        success:true,

        filename:req.file.filename,

        message:"Excel Uploaded Successfully"

    });

});

// Get Uploaded Files
app.get("/uploads",(req,res)=>{

    db.query(

        "SELECT * FROM uploaded_files ORDER BY id DESC",

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json(result);

        }

    );

});

// Delete Uploaded File
app.delete("/uploads/:id",(req,res)=>{

    db.query(

        "DELETE FROM uploaded_files WHERE id=?",

        [

            req.params.id

        ],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json({

                success:true,
                message:"File Deleted Successfully"

            });

        }

    );

});// =====================================
// BOOKMARKS & WRONG QUESTION SYSTEM
// =====================================

// Bookmark MCQ
app.post("/bookmark/add", (req, res) => {

    const {

        student_id,
        mcq_id

    } = req.body;

    db.query(

        `INSERT INTO bookmarks
        (student_id,mcq_id)
        VALUES(?,?)`,

        [

            student_id,
            mcq_id

        ],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json({

                success:true,
                message:"MCQ Bookmarked Successfully"

            });

        }

    );

});

// Get Bookmarks
app.get("/bookmark/:studentId",(req,res)=>{

    db.query(

        "SELECT * FROM bookmarks WHERE student_id=? ORDER BY id DESC",

        [

            req.params.studentId

        ],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json(result);

        }

    );

});

// Remove Bookmark
app.delete("/bookmark/:id",(req,res)=>{

    db.query(

        "DELETE FROM bookmarks WHERE id=?",

        [

            req.params.id

        ],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json({

                success:true,
                message:"Bookmark Removed"

            });

        }

    );

});

// Save Wrong Question
app.post("/wrong-question/add",(req,res)=>{

    const {

        student_id,
        mcq_id

    } = req.body;

    db.query(

        `INSERT INTO wrong_questions
        (student_id,mcq_id)
        VALUES(?,?)`,

        [

            student_id,
            mcq_id

        ],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json({

                success:true

            });

        }

    );

});

// Get Wrong Questions
app.get("/wrong-question/:studentId",(req,res)=>{

    db.query(

        "SELECT * FROM wrong_questions WHERE student_id=? ORDER BY id DESC",

        [

            req.params.studentId

        ],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json(result);

        }

    );

});

// Clear Wrong Questions
app.delete("/wrong-question/clear/:studentId",(req,res)=>{

    db.query(

        "DELETE FROM wrong_questions WHERE student_id=?",

        [

            req.params.studentId

        ],

        (err,result)=>{

            if(err){

                return res.status(500).json({

                    success:false

                });

            }

            res.json({

                success:true,
                message:"Wrong Questions Cleared"

            });

        }

    );

});// =====================================
// RANKING, MAINTENANCE & SERVER UTILITIES
// =====================================

// Overall Ranking
app.get("/ranking", (req, res) => {

    const sql = `
    SELECT
    student_id,
    AVG(percentage) AS average_percentage
    FROM results
    GROUP BY student_id
    ORDER BY average_percentage DESC
    `;

    db.query(sql, (err, result) => {

        if (err) {
            return res.status(500).json({
                success: false
            });
        }

        res.json(result);

    });

});

// Top 10 Students
app.get("/ranking/top10", (req, res) => {

    db.query(

        `SELECT
        student_id,
        AVG(percentage) AS average_percentage
        FROM results
        GROUP BY student_id
        ORDER BY average_percentage DESC
        LIMIT 10`,

        (err, result) => {

            if (err) {

                return res.status(500).json({
                    success: false
                });

            }

            res.json(result);

        }

    );

});

// Website Health Check
app.get("/health", (req, res) => {

    res.json({

        success: true,
        server: "Running",
        database: "Connected",
        status: "Healthy",
        version: "ABACADEMY v1.0"

    });

});

// Maintenance Mode
let maintenanceMode = false;

app.get("/maintenance", (req, res) => {

    res.json({

        maintenance: maintenanceMode

    });

});

app.post("/maintenance/on", (req, res) => {

    maintenanceMode = true;

    res.json({

        success: true,
        message: "Maintenance Mode Enabled"

    });

});

app.post("/maintenance/off", (req, res) => {

    maintenanceMode = false;

    res.json({

        success: true,
        message: "Maintenance Mode Disabled"

    });

});

// Server Information
app.get("/server-info", (req, res) => {

    res.json({

        platform: process.platform,
        node: process.version,
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        environment: process.env.NODE_ENV || "development"

    });

});